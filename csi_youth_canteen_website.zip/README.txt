CSI Youth Sunday Canteen — free static website

FILES
- index.html: mobile-friendly menu with item quantities, total calculation, and WhatsApp order handoff.

PUBLISH FREE WITH GITHUB PAGES
1. Sign in or create a GitHub account at https://github.com
2. Create a new public repository, for example: csi-youth-canteen
3. Upload index.html to the repository root (Add file → Upload files → Commit changes).
4. Open repository Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish. Your live URL will look like:
   https://YOUR-USERNAME.github.io/csi-youth-canteen/
   Use the exact URL shown in Settings → Pages.

CREATE A QR CODE AFTER PUBLISHING
1. Copy the exact live website URL from GitHub Pages.
2. Open a reputable QR generator such as https://www.qrcode-monkey.com/ or https://www.qr-code-generator.com/
3. Choose URL/Website, paste the live URL, and create a static QR code.
4. Download the QR as PNG or SVG and place it on the church poster.
5. Test it by scanning from another phone, ideally while not logged into GitHub.

IMPORTANT
- The QR code cannot be made reliably until the page has a live URL.
- WhatsApp order buttons open a message for the selected contact; the customer must press Send in WhatsApp.
- Check the phone numbers and menu prices before publishing.
- This page is a static website; it does not store orders or accept online payments.
